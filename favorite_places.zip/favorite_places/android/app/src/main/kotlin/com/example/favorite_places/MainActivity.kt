package com.example.favorite_places

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
