import 'package:flutter/material.dart';

import 'package:debug_harjoitus/quiz.dart';

void main() {
  runApp(const Quiz());
}
