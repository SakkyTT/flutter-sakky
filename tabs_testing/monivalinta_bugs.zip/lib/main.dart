import 'package:flutter/material.dart';
import 'package:tabs_testing/quiz.dart';

void main() {
  runApp(const Quiz()); // Nyt meidän sovellus on kokonaan Quiz luokan sisällä
} // Täällä _QuizState ei toimi
